import pandas as pd
import matplotlib as plt

df = pd.read_csv("BigMartSalesData.csv")

df_grouped_year = df.query("Year == 2011").filter(
    ["Month", "Amount"]).groupby(["Month"], as_index=False).sum()

# Plot Total Sales Per Month for Year 2011.
x = df_grouped_year["Month"]
y = df_grouped_year["Amount"]

plt.plot(x, y)
plt.xlabel("Month")
plt.ylabel("Total Sales")
plt.title("Month vs sales")
plt.grid()
plt.show()




df_grouped_country = df.query("Year == 2011").filter(
    ["Country", "Amount"]).groupby(["Country"], as_index=False).sum()

plt.pie(df_grouped_country["Amount"],
        labels=df_grouped_country["Country"],
        autopct='%1.1f%%',
        shadow=True)

plt.tight_layout()
plt.show()



invoice_amounts = df.filter(["InvoiceDate", "Amount"]).groupby(
    "InvoiceDate", as_index=False).sum()

plt.scatter(invoice_amounts["InvoiceDate"], invoice_amounts["Amount"])
plt.ylim(20000, 100000)
plt.show()
