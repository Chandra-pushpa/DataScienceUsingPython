'''
A robot moves in a plane starting from the original point (0,0).
The robot can move toward UP, DOWN, LEFT and RIGHT with a given steps. The trace of robot movement is shown as the following:
UP 5, DOWN 3, LEFT 3, RIGHT 2
The numbers after the direction are steps. Please write a program to compute the distance from current
position after a sequence of movements.
'''
import math
#Init vars
mypos = [0, 0]
moves = {"UP": [0, 1], "DOWN": [0, -1], "LEFT": [-1, 0], "RIGHT": [1, 0]}

#Set inputs
data = ["UP 5", "DOWN 3", "LEFT 3", "RIGHT 2"]

#Move robot
for i in data:
    mystr = i.split()
    mv = mystr[0]
    val = mystr[1]
    if mv in moves and val.isnumeric():
        mypos[0] += moves[mv][0]*int(val)
        mypos[1] += moves[mv][1]*int(val)

#get distance
distance = math.sqrt(mypos[0]**2 + mypos[1]**2)
print('The distance after sequence of movement is: ', round(distance, 3))





'''
Data of XYZ company is stored in sorted list. Write a program for searching specific data from that list
'''

def listSearch(mylist, mysearch):
    for i in range(len(mylist)):
        if mylist[i] == mysearch:
            return True
    return False


mylist = ['r', 'a', 'm', 'y', 'a']
mysearch = 'm'
if listSearch(mylist, mysearch):
    print("The item ", mysearch, "is found in the list")
else:
    print("The item ", mysearch, "is not found in the list")
    



'''
Weather forecasting organization wants to show is it day or night.
So, write a program for such organization to find whether is it dark outside or not
'''
import time
mytime = time.localtime()
if mytime.tm_hour < 6 or mytime.tm_hour > 18:
    print('It is night and dark outside')
else:
    print('It is a day time and not dark outside')



'''
4. Write a program to find distance between two locations when their latitude and longitudes are given.
Hint: Use math module.
'''



from math import sin, cos, sqrt, atan2, radians

# approximate radius of earth in km
R = 6373.0

lat1 = radians(52.2296756)
lon1 = radians(21.0122287)
lat2 = radians(52.406374)
lon2 = radians(16.9251681)

d_lon = lon2 - lon1
d_lat = lat2 - lat1

a = sin(d_lat / 2)**2 + cos(lat1) * cos(lat2) * sin(d_lon / 2)**2
c = 2 * atan2(sqrt(a), sqrt(1 - a))

distance = R * c

print('Distance:', round(distance, 2), 'km')





'''
Design a software for bank system. There should be options like cash withdraw,
cash credit and change password. According to user input,
the software should provide required output.
'''


balance = 25000
def CashWithdrawal():
    try:
        PIN = int(input('Enter PIN to proceed:'))
        if PIN == 1234:
            amount = int(input('Enter the amount : '))
            global balance
            balance -= amount
            print('Current balance is ', balance)
            print('Thank You For Banking With Us')
        else:
            print('You Have Entered Invalid PIN. Try Again')
    except:
        print('Invalid entry')


def CashDeposit():
    try:
        PIN = int(input('Enter ATM PIN to proceed :'))
        if PIN == 1234:
            amount = int(input('Enter Amount That You Wish to Deposit :'))
            global balance
            balance += amount
            print('Current balance is ', balance)
            print('Thank You For Banking With Us')
        else:
            print('You Have Entered Invalid PIN. Try Again')
    except:
        print('Invalid entry')

def ChangePin():
    try:
        PIN = int(input('Enter ATM or CARD PIN to proceed :'))
        if PIN == 1234:
            new_pwd1 = int(input('Please Enter Your new Password :'))
            new_pwd2 = int(input('Please Enter Your new Password again :'))
            if new_pwd1 == new_pwd2:
                PIN = new_pwd1
                print("PIN changed successfully")
                print('Thank You For Banking With Us')
        else:
            print('You Have Entered Invalid PIN. Try Again')
    except:
        print('Invalid entry')


print('Welcome to XYZ Bank\nChoose from below options')
print('1. Case withdrawal\n2. Cash credit\n3. Change password')
while True:
    opt = int(input('Enter your option:'))
    if opt == 1:
        CashWithdrawal()
        break
    elif opt == 2:
        CashDeposit()
        break
    elif opt == 3:
        ChangePin()
        break
    else:
        print('Invalid entry')
        continue





    #Write a program which will find all such numbers which are divisible by 7
# but are not a multiple of 5, # between 2000 and 3200 (both included).
# The numbers obtained should be printed in a comma-separated sequence on a single line

mylist = []
for i in range(2000, 3201):
    if (i % 7 == 0) and (i % 5 != 0):
        mylist.append(str(i))
print(','.join(mylist))





#Write a program which can compute the factorial of a given numbers. Use recursion to find it.


def recur_fact(n):
    if n == 1:
        return n
    else:
        return n * recur_fact(n-1)


num = int(input("Enter a number: "))

if num < 0:
    print("Sorry, factorial does not exist for negative numbers")
elif num == 0:
    print("The factorial of 0 is 1")
else:
    print("The factorial of", num, "is", recur_fact(num))




    '''
Write a program that calculates and prints the value according to the
given formula:Q = Square root of [(2 * C * D)/H]Following are the fixed values of C and H: C is 50.
H is 30.D  is  the  variable  whose  values  should  be  input  to  your  program  in  a  comma-separated sequence

Example:
    Let  us  assume  the  following  comma  separated
    input  sequence  is  given  to  the program:100,150,180
    The output of the program should be:18,22,24
'''

import math
c = 50
h = 30
result = []
user_input = input('Enter the numbers separated by comma : ')
try:
    items = [x for x in user_input.split(',')]
    for d in items:
        ans = round(math.sqrt(2 * c * float(d)/h))
        result.append(str(ans))
    print(','.join(result))
except:
    print('Invalid input')







    '''
Write a program which takes 2 digits, X,Y as input and generates a 2-dimensional array.
The element value in the i-th row and j-th column of the array should be i*j.
Note: i=0,1.., X-1; j=0,1,¡-Y-1.
Example:Suppose the following inputs are given to the program:3,5
Then, the output of the program should be:[[0, 0, 0, 0, 0], [0, 1, 2, 3, 4], [0, 2, 4, 6, 8]]
'''


x = int(input("Input number of rows: "))
y = int(input("Input number of columns: "))
multi_list = [[0 for col in range(y)] for row in range(x)]

for r in range(x):
    for c in range(y):
        multi_list[r][c] = r * c

print(multi_list)






'''
Write a program that accepts a comma separated sequence of words as input and prints the words in a
 comma-separated sequence after sorting them alphabetically.
Suppose the following input is supplied to the program:without,hello,bag,world
Then, the output should be:bag,hello,without,world
'''

mystr = input('Enter the strings separated by comma : ')

mylist = []

for i in mystr.split(','):
    mylist.append(i)
mylist.sort()
print('Sorted list : ')
print(','.join(mylist))





'''
Write a program that accepts sequence of lines as input and prints the lines
after making all characters in the sentence capitalized.
Suppose the following inputis supplied to the program:
Hello world
Practice makes perfect
Then, the output should be:
HELLO WORLD
PRACTICE MAKES PERFECTw
'''

lines = []
while True:
    l = input()
    if l:
        lines.append(l.upper())
    else:
        break;

for l in lines:
    print(l)






    '''
Write a program that accepts a sequence of whitespace separated words as input and   prints   the   words   after
 removing   all   duplicate   words   and   sorting   them alphanumerically.
 Suppose the following input is supplied to the program:
hello world and practice makes perfect and hello world again
Then, the output should be:
again and hello makes perfect practice world
'''

mystr = input('Enter sequence of words : ')
myset = set()
mylist = []
for i in mystr.split(' '):
    myset.add(i)
print(myset)
sortedSet = sorted(myset)
print(sortedSet)
for i in sortedSet:
    mylist.append(i)
print(' '.join(mylist))




'''
Write  a  program  which  accepts  a  sequence  of  comma  separated  4  digit  binary numbers  as  its  input  and
then  check  whether  they  are  divisible  by  5  or  not.
The numbers that are divisible by 5 are to be printed in a comma separated sequence
'''

mylist = []
numlist = []
my_input = input('Enter four digits separated by comma : ')
try:
    for i in my_input.split(','):
        numlist.append(i)
    for i in numlist:
        x = int(i, 2)
        if not x % 5:
            mylist.append(i)
    print('The numbers division by 5 are : ')
    print(','.join(mylist))
except:
    print('Invalid input')





'''
Write  a  program  that  accepts  a  sentence  and  calculate  the  number  of  upper  case letters and lower case letters
'''


mystr = input("Enter a string : ")
mydict = {'uppercase': 0, 'lowercase': 0}
for i in mystr:
    if i.isupper():
        mydict['uppercase'] += 1
    elif i.islower():
        mydict['lowercase'] += 1
    else:
        pass
print('Number of upper case characters : ', mydict['uppercase'])
print('Number of lower case characters : ', mydict['lowercase'])





'''
Give example of fsum and sum function of math library.
'''


    import math
#fsum
print('fsum result : ', math.fsum(range(10)))

#sum
sum = 0;
for i in range(10):
    sum += i
print('sum result: ', sum)



















    





    
