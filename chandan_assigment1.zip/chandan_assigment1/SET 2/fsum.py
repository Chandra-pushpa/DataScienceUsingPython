import math
#fsum
print('fsum result : ', math.fsum(range(10)))

#sum
sum = 0;
for i in range(10):
    sum += i
print('sum result: ', sum)